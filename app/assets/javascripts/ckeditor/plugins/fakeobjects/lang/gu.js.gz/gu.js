/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'fakeobjects', 'gu', {
	anchor: 'અનકર',
	flash: 'ફ્લેશ ',
	hiddenfield: 'હિડન ',
	iframe: 'IFrame',
	unknown: 'અનનોન ઓબ્જેક્ટ'
} );
