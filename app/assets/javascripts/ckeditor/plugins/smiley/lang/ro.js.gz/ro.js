/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("smiley","ro",{options:"Opțiuni figuri expresive",title:"Inserează o figură expresivă (Emoticon)",toolbar:"Figură expresivă (Emoticon)"});