/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'smiley', 'zh', {
	options: 'Smiley Options', // MISSING
	title: '插入表情符號',
	toolbar: '表情符號'
});
