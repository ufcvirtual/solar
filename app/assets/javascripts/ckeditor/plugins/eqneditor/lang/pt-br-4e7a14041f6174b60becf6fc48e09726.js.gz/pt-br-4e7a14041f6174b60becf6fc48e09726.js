CKEDITOR.plugins.setLang( 'eqneditor', 'pt-br',
{
	title: 'Editor Matemático',
	menu: 'Matemática',
	toolbar: 'Editor Matemático',
	edit: 'Editar Equação'
});
