
CKEDITOR.plugins.setLang( 'eqneditor', 'pt-br',
{
	title	: 'Editor Matemático',
	menu    : 'Matemática',
	toolbar	: 'Inserir Equação',
	edit	: 'Editar Equação'
});
